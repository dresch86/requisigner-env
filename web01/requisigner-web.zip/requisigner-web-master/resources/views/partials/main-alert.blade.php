<div id="requisigner-main-alert-box" class="d-none flex-row justify-content-between align-items-center mb-2 alert" role="alert">
    <div class="alert-text"></div>
    <button type="button" class="alert-dismiss-btn"><span aria-hidden="true">×</span></button>
</div>